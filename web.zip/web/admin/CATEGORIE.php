<?php
$con = mysqli_connect('localhost', 'root', '', 'db');

if ($con) {
    
    echo "";
} else {
    echo "Connection Failed";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $corse_name = $_POST['fullname'];

    $query = "INSERT INTO categories (corse_name) VALUES ('$corse_name')";
    mysqli_query($con, $query);
    header('location: CATEGORIE.php');
    
}
?>
<!DOCTYPE html>
<html>
<head>
     <title>Categories</title>
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min(1).css">
    
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>
<body>
     <div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-reed text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="adminpage.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="CATEGORIE.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Categories</span> </a>
                        
                    </li>
                    
                    <li>
                        <a href="content.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Content</span> </a>
                           
                    </li>
                    <li>
                        <a href="blog.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Blog</span> </a>
                    </li>
                    <li>
                        <a href="userinfo.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                    </li>



                </ul>
                <hr>
                <div class="dropdown pb-4">
                             
                     <a class="nav-link px-0 align-middle" href="logout.php">Sign out</a>
                    
                </div>
            </div>
        </div>
        <div class="col py-3">
            
            <p class="lead">
            <h3><p class="text-primary">Insert Course Categories</h3></p>
                    

                    <form action="" method="post" enctype="multipart/form-data">
                    
                    <div class="form-group">
                        <label for="CourseId1">Course Categorie</label>
                        <input type="text" id="CourseId1" placeholder="Full Name" name="fullname" class="form-control" title="Only lower and upper case and space" pattern="[A-Za-z/\s]+">
                        <?php if(isset($message_name)){ echo $message_name; } ?>
                    </div>
                    
                    <div class="form-group">
                        <button name="submit" class="btn btn-outline-primary" type="submit">Submit</button>





                    </div>


                          <div class="container clearfix" >
                        <table class="table table-hover">
    <tr class="table-active" >
        <th>ID</th>
        <th>Course Categories</th>
        
    </tr>
    <?php

        $query = "SELECT * FROM `categories`";

        $result = mysqli_query($con, $query);

        if(mysqli_num_rows($result) > 0){
        
                        //We have data 
                        //output the data
         while( $row = mysqli_fetch_assoc($result) ){
                echo "<tr>";
echo "<td>".$row["ID"]."</td> <td>".$row["corse_name"]."</td>";

                echo "<tr>";  
            }
    } else {
        echo "<div class='alert alert-danger'>You have no courses.<a class='close' data-dismiss='alert'>&times</a></div>";
    }
    
    // close the mysql 
        mysqli_close($con);
    ?>

    <tr>
        <td colspan="4" id="end"><div class="text-center"><a href="categorie.php" type="button" class="btn btn-sm btn-success"><span class="icon-plus"></span></a></div></td>
    </tr>
</table>
</div>






                </form>
            </ul>
        </div>
    </div>
</div>






</body>
</html>