<?php
    include("db.php");
    error_reporting(0);

    if(isset($_POST['submit']))
    {
        $user_name = $_POST['user_name'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $id = $_POST['id'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['c_pass'];

        if ($password === $confirmPassword) {
            // Update the user data in the database
            $sql = "UPDATE users SET user_name='$user_name', password='$password', name='$name', Email='$email' WHERE id='$id'";
            $value = $conn->query($sql);
            if($value === TRUE){
                header("Location: updatAdmin.php?id=$id&success=Info updated successfully");
            }else{
                header("Location: updatAdmin.php?id=$id&error=Something went wrong.");
            }
        } else {
            header("Location: updatAdmin.php?id=$id&error=Passwords don't match.");
        }
    }
?>