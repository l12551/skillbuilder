<?php
 require('config/db.php');
 //create a query
 $query = 'SELECT * FROM users WHERE user_type = "user"';
 //get result 
 $result = mysqli_query($conn, $query);
 //fetch data (associative array is basically: ['name' => username])
 $user = mysqli_fetch_all($result, MYSQLI_ASSOC);
 //var_dump($user);
 // free result (free it from memory)
 mysqli_free_result($result);

?>
<!DOCTYPE html>
<html>
<head>
     <title>Users info</title>
     <meta charset="utf-8">
     <link rel="stylesheet" type="text/css" href="style.css">
 
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min(1).css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>
<body   height:95vh  >
     
     <div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-reed text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="adminpage.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="CATEGORIE.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Categories</span> </a>
                        
                    </li>
                   
                    
                    <li>
                        <a href="content.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Content</span> </a>
                            
                    </li>
                    <li>
                        <a href="blog.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Blog</span> </a>
                    </li>
                    <li>
                        <a href="userinfo.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                    </li>



                </ul>
                <hr>
                <div class="dropdown pb-4">
                             
                     <a class="nav-link px-0 align-middle" href="logout.php">Sign out</a>
                    
                </div>
            </div>
        </div>
        <div class="col py-3">
        
        <h3><p class="text-primary"> User information:</h3></p>

        
        
        <table class="table table-hover">
    <tr class="table-active">
        <th>ID</th>
        <th>Name</th>
        <th>user Name</th>
        <th>password</th>
        <th>Email</th>
        
    </tr>
    <?php
     $query = 'SELECT * FROM users WHERE user_type = "user"';
     //get result 
     $result = mysqli_query($conn, $query);
     //fetch data (associative array is basically: ['name' => username])



        if(mysqli_num_rows($result) > 0){
        
                        //We have data 
                        //output the data
         while( $row = mysqli_fetch_assoc($result) ){
                echo "<tr>";
                echo "<td>".$row["id"]."</td> <td>".$row["user_name"]."</td> <td>".$row["password"]."</td> <td>".$row["name"]."</td> <td>".$row["Email"]."</td>" ;

                echo "<tr>";  


            }}

      else {
        echo "<div class='alert alert-danger'>You have no courses.<a class='close' data-dismiss='alert'>&times</a></div>";
    }
    
   
    // close the mysql 
        mysqli_close($conn);
    ?>

    <tr>
        <td colspan="4" id="end"><div class="text-center"><a href="categorie.php" type="button" class="btn btn-sm btn-success"><span class="icon-plus"></span></a></div></td>
    </tr>
</table>
</div>
        





















    </div>
</div>
    
</body>
</html>