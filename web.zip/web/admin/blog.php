<?php
$con = mysqli_connect('localhost', 'root', '', 'db');

if ($con) {
   
    
} else {
    echo "Connection Failed";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $title = mysqli_real_escape_string($con,$_POST['title']);
    $content = mysqli_real_escape_string($con,$_POST['content']);
    $option = $_POST["contentsel"];
    $newfilename = $_POST["link"];

    $postDate = date("F d, Y");
    

 $loginId = $_SESSION['userId'];
    $query =  "INSERT INTO `blog` (postContent, postDate, admin, title, status, post) VALUES ('$content','$postDate','$loginId','$title','$option','$newfilename')";
    mysqli_query($con, $query);
    header('location: blog.php');
    
}



?>


<!DOCTYPE html>
<html>
<head>
     <title>blog</title>
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min(1).css">
     
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>
<body>
     <div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-reed text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="adminpage.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="CATEGORIE.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Categories</span> </a>
                        
                    </li>
                   
                    
                    <li>
                        <a href="content.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Content</span> </a>
                            
                    </li>
                    <li>
                        <a href="blog.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Blog</span> </a>
                    </li>
                    
                    <li>
                        <a href="userinfo.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                    </li>



                </ul>
                <hr>
                <div class="dropdown pb-4">
                             
                     <a class="nav-link px-0 align-middle" href="logout.php">Sign out</a>
                    
                </div>
            </div>
        </div>
        <div class="col py-3">
        <h3><p class="text-primary">Insert Post :</h3></p>

<form action="" method="post" enctype="multipart/form-data">

<div class="form-group">
<label for="titleID1">Title</label>
<input type="text" id="titleID1" placeholder="Title" name="title" class="form-control">
<?php if(isset($message_title)){ echo $message_title; } ?>
</div>


<div class="form-group">                    
<label>Post Selection</label>
<select class="form-control"  name="contentsel" id="contentsel" onchange="showinput()">
<option value="">Select Option</option>
<?php 
     $select = ["video","image"];
     foreach ($select as $value) {
?>

<option value="<?php echo $value; ?>" > <?php echo $value; ?>  </option>

<?php       
}
?>

</select>
</div>
<?php if(isset($message_option)) echo $message_option; ?>

<div id="data">


</div>


<div class="form-group">
<label for="contentID1">Post Content</label>
<textarea id="contentID1" class="form-control" 
 name="content"></textarea>
</div>
<?php if(isset($message_con)) echo $message_con; ?>   
<div class="form-group">
<button name="submit" class="btn btn-outline-primary" type="submit">Submit</button>
</div>
</form>

<!--%%%%%%%%%%%%%%%% HERE DISPLAY TABLE %%%%%%%%%%%%%%%%% -->


<table class="table table-hover">
<tr class="table-active">
<th>ID</th>
<th>Post</th>
<th>Title</th>
<th>Post Content</th>
<th>Post Date</th>

</tr>
<?php

$query = "SELECT * FROM `blog`";

$result = mysqli_query($con, $query);

if(mysqli_num_rows($result) > 0){

//We have data 
//output the data
while( $row = mysqli_fetch_assoc($result) ){
echo "<tr>";
echo "<td>".$row["id"]."</td>"; 
if($row["status"]=='image'){

echo "<td><img src=images/blog/".$row["post"]." width='80px' height='80px'> </td> "; 
}else{ ?>


    <td width="80" height="80"> <iframe width="80px" height="80px" src="https://www.youtube.com/embed/<?php echo $row['post']; ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></a>
     </td>


<?php }   


echo "<td>".$row["title"]."</td> <td> ".$row["postContent"]."</td><td> ".$row["postDate"]."</td>";



echo "<tr>";  
}
} else {
echo "<div class='alert alert-danger'>You have no posts.<a class='close' data-dismiss='alert'>&times</a></div>";
}

// close the mysql 
mysqli_close($con);
?>

<tr>
<td colspan="7" id="end"><div class="text-center"><a href="blog.php" type="button" class="btn btn-sm btn-success"><span class="icon-plus"></span></a></div></td>
</tr>
</table>

<!-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->




</div><!-- .postcontent end -->


</div>

</div>

</section><!-- #content end -->

<script>
function showinput(){
var select = document.getElementById('contentsel');
select = select.value;
if(select=='video')
{
document.getElementById('data').innerHTML =  
`<div class="form-group">
       <label for="linkID1">Video Link</label>
       <input type="url" id="linkID1" placeholder="Link" name="link" class="form-control">
    </div>
<?php if(isset($message_picture)){ echo $message_picture; } ?>`;
} else if(select=='image'){
document.getElementById('data').innerHTML =  
`<div class="form-group">
    <label class="btn btn-outline-danger" for="my-file-selector">
    <input id="my-file-selector" name="profilePic" type="file" style="display:none;" onchange="$('#upload-file-info').html($(this).val());">
    Profile Picture
    </label>
    <span class='label label-success' id="upload-file-info"></span>
<?php if(isset($message_picture)){ echo $message_picture; } ?>
</div>`;
} else {
document.getElementById('data').innerHTML =  
``;
}

} 
</script>
            


        </div>
    </div>
</div>
    
</body>
</html>























