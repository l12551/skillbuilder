<?php
$con = mysqli_connect('localhost', 'root', '', 'db');

if (!$con) {
    echo "Connection Failed: " . mysqli_connect_error();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();

    // Assuming you have already established a database connection

    // Retrieve the updated values from a form or any other source
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];
    $Email = $_POST['Email'];
    $id = $_SESSION['id'];

    // Prepare the SQL select statement to fetch user data
    $selectSql = "SELECT * FROM users WHERE id = ?";
    $selectStmt = mysqli_prepare($con, $selectSql);
    mysqli_stmt_bind_param($selectStmt, "i", $id);
    mysqli_stmt_execute($selectStmt);
    $result = mysqli_stmt_get_result($selectStmt);
    $user = mysqli_fetch_assoc($result);

    if (!$user) {
        echo "User not found.";
        exit;
    }

    // Prepare the SQL update statement
    $updateSql = "UPDATE users SET user_name = ?, password = ?, Email = ? WHERE id = ?";
    $updateStmt = mysqli_prepare($con, $updateSql);
    mysqli_stmt_bind_param($updateStmt, "sssi", $user_name, $password, $Email, $id);

    // Execute the statement
    if (mysqli_stmt_execute($updateStmt)) {
        if (mysqli_stmt_affected_rows($updateStmt) > 0) {
            echo "User details updated successfully.";
        } else {
            echo "No changes were made to the user details.";
        }
    } else {
        echo "Error updating user details: " . mysqli_stmt_error($updateStmt);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
     <title>Users info</title>
     <meta charset="utf-8">
     
 
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min(1).css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>
<body   height:95vh  >
     
     <div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-reed text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="adminpage.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="CATEGORIE.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Categories</span> </a>
                        
</li>
                    
                    <li>
                        <a href="content.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Content</span> </a>
                            
                    </li>
                    <li>
                        <a href="blog.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Blog</span> </a>
                    </li>
                
                    <li>
                        <a href="userinfo.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                    </li>



                </ul>
                <hr>
                <div class="dropdown pb-4">
                             
                     <a class="nav-link px-0 align-middle" href="logout.php">Sign out</a>
                    
                </div>
            </div>
        </div>
       
        <div class="col py-3">
            
            <p class="lead">

                    <h3><p class="text-primary">Update youre profile information :</h3></p>

                    <form action="" method="post" enctype="multipart/form-data">
                    
                    <div >
                    

                        <label for="username">New user name </label>
                        <input type="text" id="user_name" placeholder="New user name" name="user_name" class="form-control" title="Only lower and upper case and space" pattern = "[A-Za-z0-9\s\W]+"">
                        <?php if(isset($message_name)){ echo $message_name; } ?>

                        <label for="password">New Password </label>
                        <input type="text" id="password" placeholder="password" name="password" class="form-control" title="Only lower and upper case and space" pattern = "[A-Za-z0-9\s\W]+"">
                        <?php if(isset($message_name)){ echo $message_name; } ?>

                        <label for="Email">New Email </label>
                        <input type="text" id="Email" placeholder="Email" name="Email" class="form-control" title="Only lower and upper case and space" pattern = "[A-Za-z0-9\s\W]+"">
                        <?php if(isset($message_name)){ echo $message_name; } ?>


                        <button name="submit" class="btn btn-outline-primary" type="submit">Update</button>


                    </div>

    </div>
</div>
    
</body>
</html>
