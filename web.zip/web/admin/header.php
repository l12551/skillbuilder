<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" type="png" href="logo.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo "Skillbuilder"; ?></title>
    <meta name="desciption" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="header-style.css">
    <script type="text/javascript" src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    <script>
        $(window).on('scroll', function(){
            if($(window).scrollTop()){
              $('nav').addClass('black');
             }else {
           $('nav').removeClass('black');
         }
        })
    </script>
</head>
<body>
 <!-- Navigation Bar -->
    <header id="header">
        <nav>
            <div class="logo"><img src="logo1.png" alt="logo"></div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="skillbuilder.php">skillbuilder</a></li>
                <li><a href="team.php">Team</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="search.php">Search</a></li>
                <li><a href="contact.php">Contact</a></li>
                
            </ul>
            <a class="get-started" href="../admin/index.php">Get Started</a>
        </nav>
</body>
</html>
