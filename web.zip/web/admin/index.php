<!DOCTYPE html>
<html>
<head>
	<title>LOG IN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="../style.css" type="text/css" />
	<link rel="stylesheet" href="../css/dark.css" type="text/css" />
	<link rel="stylesheet" href="../css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="../css/animate.css" type="text/css" />
	<link rel="stylesheet" href="../css/magnific-popup.css" type="text/css" />
	
	<link rel="stylesheet" href="../css/responsive.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
</head>
<body>
	<form action="login.php" method="post">
		<h2>LOG IN</h2>
		<?php if (isset($_GET['error'])) { ?>
			<p class="error"><?php echo $_GET['error']; ?></p>
		<?php } ?>
		<label>Username:</label>
		<input type="text" name="uname" placeholder="Username"><br>

		<label>Password:</label>
		<input type="password" name="password" placeholder="Password"><br>

		<label>User Type</label>
		<select name="user-type">
			<option value="admin">Admin</option>
			<option value="user">User</option>
		</select><br>
<br>
		<button type="submit">Login</button>
		<a href="signup.php" class="ca">Create an account</a>
	</form>
</body>
</html>
