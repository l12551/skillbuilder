
<?php 
session_start(); 
include "connection.php";
if (isset($_POST['uname']) && isset($_POST['password']) && isset($_POST['user-type'])) {

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);
    $userType = validate($_POST['user-type']);

    if (empty($uname)) {
        header("Location: index.php?error=Username is required");
        exit();
    } else if (empty($pass)){
        header("Location: index.php?error=Password is required");
        exit();
    } else if (empty($userType)){
        header("Location: index.php?error=User Type is required");
        exit();
    } else {
        $sql = "SELECT * FROM users WHERE user_name='$uname' AND password='$pass' AND user_type='$userType'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            if ($row['user_name'] === $uname && $row['password'] === $pass && $row['user_type'] === $userType) {
                $_SESSION['user_name'] = $row['user_name'];
                $_SESSION['name'] = $row['name'];
                $_SESSION['id'] = $row['id'];
                
                if ($userType === 'admin') {
                    header("Location: adminpage.php");
                    exit();
                } else if ($userType === 'user') {
                    header("Location: ../user/w/userpage.php");
                    exit();
                }
            } else {
                header("Location: index.php?error=Incorrect Username, Password, or User type");
                exit();
            }
        } else {
            header("Location: index.php?error=Incorrect Username, Password, or User type");
            exit();
        }
    }
    
} else {
    header("Location: index.php");
    exit();
}


