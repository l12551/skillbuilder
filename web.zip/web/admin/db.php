<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$db_name = "db";  
$password = "root";
 // Create Connection
 $conn = mysqli_connect($servername, $username, $password, $db_name); 
 if($conn){
    // echo "Connection ok";
 }
 else{
 echo 'Failed to connect to MySQL '. mysqli_connect_errno();
 }
?>