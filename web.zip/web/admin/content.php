<?php
$con = mysqli_connect('localhost', 'root', '', 'db');

if ($con) {
   
    
} else {
    echo "Connection Failed";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $categories = $_POST['categories'];
    $content=$_POST['content'];
    $lectureName=$_POST['lectureName'];
    

    $query = "INSERT INTO content (content,lectureName,categories) VALUES ('$content','$lectureName','$categories')";
    mysqli_query($con, $query);
    header('location: content.php');
    
}


?>


<!DOCTYPE html>
<html>
<head>
     <title>content</title>
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min(1).css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>
<body>
     <div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-reed text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="adminpage.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="CATEGORIE.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Categories</span> </a>
                        
                    </li>
                    
                    
                    <li>
                        <a href="content.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Content</span> </a>
                           
                    </li>
                    <li>
                        <a href="blog.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Blog</span> </a>
                    </li>
                   
                    <li>
                        <a href="userinfo.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                    </li>



                </ul>
                <hr>
                <div class="dropdown pb-4">
                             
                     <a class="nav-link px-0 align-middle" href="logout.php">Sign out</a>
                    
                </div>

            </div>
        </div>
        <div >
        <h3><p class="text-primary">Insert Course Content</h3></p>
                    

        <form action="" method="post" enctype="multipart/form-data">

                 <div class="col-sm-10">
                <label for="nameId1" class="form-control">Lecture Name</label>
                <input type="text" id="nameId1" placeholder="Lecture Name" name="lectureName" class="form-control" title="Only lower and upper case and space" pattern="[A-Za-z/\s]+">
                <?php if(isset($message_name)){ echo $message_name; } ?>
                </div>

                <div class="form-group">                    
              <label class="form-control">corse Selection</label>
               <select class="form-select"  name="categories">
                <?php 

                   $query = "SELECT * FROM `categories`";

                    $result = mysqli_query($con, $query);

                    if(mysqli_num_rows($result) > 0){



                        while( $row = mysqli_fetch_assoc($result) ){
                ?>
                            
                            <option value="<?php echo $row['ID']; ?>"> <?php echo $row['corse_name']; ?>  </option>

                                <?php      } }?> 

     </select>
        <?php if(isset($course_error)) echo $course_error; ?>
</div>

<textarea class="ckeditor" name="content"></textarea>
<?php if(isset($message_Content)) echo $message_Content; ?>

<div class="form-group">
<button name="submit" class="btn btn-outline-primary" type="submit">Submit</button>
</div>
</form>


       
 

<!--%%%%%%%%%%%%%%%% HERE DISPLAY TABLE %%%%%%%%%%%%%%%%% -->


<table class="table table-hover">
<tr class="table-active">
<th>ID</th>
<th>Content</th>
<th>Lecture Name</th>
<th>Course Name</th>


</tr>
<?php

$query = "SELECT * FROM `content`";

$result = mysqli_query($con, $query);

if(mysqli_num_rows($result) > 0){

//We have data 
//output the data
while( $row = mysqli_fetch_assoc($result) ){

$temp = $row['categories'];
$query2 = "SELECT * FROM `categories` WHERE ID='$temp' ";
$result2 = mysqli_query($con, $query2);

if(mysqli_num_rows($result2) > 0){

//We have data 
//output the data
while( $row2 = mysqli_fetch_assoc($result2) ){

$courseName = $row2['corse_name']; 
}} else{$courseName='Insert Course Name';}

echo "<tr>";

echo "<td>".$row["id"]."</td> <td>".$row["content"]."</td> <td>".$row["lectureName"]."</td> <td>".$courseName."</td>";//CONTENT PLAYCE






echo "<tr>";  
}
} else {
echo "<div class='alert alert-danger'>You have no Content.<a class='close' data-dismiss='alert'>&times</a></div>";
}

// close the mysql 
mysqli_close($con);
?>

<tr>
<td colspan="6" id="end"><div class="text-center"><a href="content.php" type="button" class="btn btn-sm btn-success"><span class="icon-plus"></span></a></div></td>
</tr>
</table>
</di>
<!-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->




</div><!-- .postcontent end -->


</div>

</div>

</section><!-- #content end -->
<script src="ckeditor/ckeditor.js" type="text/javascript"></script>


    </div>
</div>
    
</body>
</html>