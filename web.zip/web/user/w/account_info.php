<?php
include("db.php");

error_reporting(0);

session_start();

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    // Redirect to login page or handle authentication
    header("Location: login.php");
    exit();
}

// Retrieve user ID from session
$user_id = $_SESSION['id'];

// Fetch user data from the database
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result) {
    // Handle database error
    echo "Error: " . mysqli_error($conn);
    exit();
}

// Check if user exists
if (mysqli_num_rows($result) == 0) {
    // User not found, handle appropriately
    echo "User not found";
    exit();
}

// Fetch user data
$user_data = mysqli_fetch_assoc($result);

// Extract user details
$user_id = $user_data['id'];
$user_name = $user_data['user_name'];
$name = $user_data['name'];
$user_type = $user_data['user_type'];
$email = $user_data['Email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styleuser.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <title>View Profile</title>
    <style>
          * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: "Nunito", sans-serif;}
             .theme-text {
                color: #474af0;}
                body{
   background-color: var(--light-bg);
   padding-left: 30rem;
}

body.dark{
   --light-color:#aaa;
   --light-bg:#333;
   --black:#fff;
   --white:#222;
   --border:.1rem solid rgba(255,255,255,.2);
}

body.active{
   padding-left: 0;
}

section{
   padding:2rem;
   margin: 0 auto;
   max-width: 1200px;
}

.heading{
   font-size: 2.5rem;
   color:var(--black);
   margin-bottom: 2.5rem;
   border-bottom: var(--border);
   padding-bottom: 1.5rem;
   text-transform: capitalize;
}

            .user-profile .detalis{
                background-color: var(--white);
                border-radius: .5rem;
                 padding: 10px;
            }
            .user-profile .info .user{
                 text-align: center;
                 margin-bottom: 2rem;
                   padding: 1rem;}
             .user-profile .info .user h3{
                 font-size: 20px;
                 color: var(--black);}
             
                .btn,
                .inline-btn{
                     background-color: var(--main-color);}

   .user-profile .info .user img{
            height: 150px;
            width: 150px;
            border-radius: 100px;
            display:block;
            margin: 50px auto;

        }
        .uu{
            background-color:white;
            padding-top:none;
            padding: 0px;
            text-align: center;
            height: 30px; /* Make background container cover entire viewport height */
            display: flex;
            align-items: center; /* Vertically center content */
            justify-content: space-between; /* Space between content and image */
        }

        .update-profile-link {
            display: block;
            width: fit-content;
            margin: 0 auto;
            background-color: pink;
            padding: 10px 20px;
            border-radius: 5px;
            text-align: center;
            color: white;
            text-decoration: none;
            transition: background-color 0.3s ease;
        
    }

    /* Hover effect for the "Update Profile" link */
    .update-profile-link:hover {
        background-color: #ff6b9c; /* Lighter pink */
    }
    .form-container {
        background-color: white;
        border-radius: 10px;
        padding: 20px;
        border: 1px solid #ccc;
        width: 400px;
    }

    .form-container h3 {
        text-align: center;
        margin-bottom: 20px;
    }

    .form-container p {
        margin-bottom: 5px;
    }

    .form-container .box {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    
    .form-container .btn {
        width: 100%;
        padding: 10px;
        background-color: #474af0;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
    }
    .form-container .btn:hover {
            background-color: #1a1ae8;
        }


    </style>
</head>
<body>

<?php include "nav.php" ?>
<section class="user-profile">
    <h1 class="heading" style="text-align: center; padding-top: 300px;">Your Profile</h1>
    <hr style="width: 100%; border: 1px solid black; margin: 0 auto;"> <!-- Updated to color black -->

    <div class="info">
        <div class="user" style="background-color: white; border-radius: 10px; padding: 20px;">
            <img src="ppp.jpg" alt="Profile Picture">
            <div class="info container">
                <h3>User Name: <?php echo $user_name; ?></h3>
                <h3>Name: <span><?php echo $name; ?> </span></h3>
                <h3>User Type: <span><?php echo $user_type; ?> </span></h3>
                <h3>Email: <span><?php echo $email; ?> </span></h3>
                <div class="uu">
                    <a href="update.php?id=<?php echo $user_id; ?>" class="update-profile-link" data-active>Update Profile</a>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>