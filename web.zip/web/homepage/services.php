<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="service-styling.css">
    <title>Our Services</title>
</head>
<body>
	<?php include 'header.php'; ?>
    <div class="container-fluid">
     <center><p style="font-size: 50px; margin-top:100px; color: #073052; padding: 100px"> Skillbuilder Services</p></center>
        <div class="row mb-5">
            <div class="col-12 col-sm-6 col-md-3 m-auto">
                <div class="card shadow">
                    <img src="online.png" alt="" class="card-img-top">
                    <div class="card-body">
                        <h3 class="text-center">Online courses</h3>
                        <hr class="mx-auto w-75">
                        <p>
                            Expand your knowledge and skills with our cutting-edge online  courses
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 m-auto">
                <div class="card shadow">
                    <img src="online2.png" alt="" class="card-img-top">
                    <div class="card-body">
                        <h3 class="text-center"> Skills category </h3>
                        <hr class="mx-auto w-75">
                        <p>
                           Unlock a world of educational opportunities through our informations about skills.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 m-auto">
                <div class="card shadow">
                    <img src="online3.png" alt="" class="card-img-top">
                    <div class="card-body">
                        <h3 class="text-center">Searching about skills </h3>
                        <hr class="mx-auto w-75">
                        <p>
                            Search about skills to got brief descreption.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 m-auto">
                <div class="card shadow">
                    <img src="online4.png" alt="" class="card-img-top">
                    <div class="card-body">
                        <h3 class="text-center">Contat Us</h3>
                        <hr class="mx-auto w-75">
                        <p>
                            Send form with the message that user want to ask about.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf"
        crossorigin="anonymous"></script>
</body>
</html>
