<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" type="png" href="logo.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Comaptible" content="IE=edge">
    <title><?php echo "Team"; ?></title>
    <meta name="desciption" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="team-style.css">
    <script type="text/javascript" src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    <script>
        $(window).on('scroll', function(){
            if($(window).scrollTop()){
              $('nav').addClass('black');
             }else {
           $('nav').removeClass('black');
         }
        })
    </script>
</head>
<body>
<?php include 'header.php'; ?>
		<div class="diffSection" id="team_section">
			<center><p style="font-size: 50px; color: #354596; margin-top: 180px; font-weight:bold; padding-bottom: 60px;">We're the Creators!</p></center>
			<div class="totalcard">
				<div class="card">
					<center><img src="z1.png"></center>
					<center><div class="card-title">Zahra Albeesh</div>
					<div id="detail">
						<p>“ Education is the key to unlocking one's full potential and empowering individuals to pursue their dreams and aspirations.“</p>
					<div class="duty"></div>
				</div>
				</center>
			</div>
			<div class="card">
				<center><img src="l.png"></center>
				<center><div class="card-title">Layan Alhonita</div>
				<div id="detail">
					<p>“ A quality education lays the foundation for personal growth, critical thinking, and lifelong learning, equipping individuals with the skills they need to adapt and thrive in a rapidly changing world. “</p>
					<div class="duty"></div>
				</div>
				</center>
			</div>
			<div class="card">
				<center><img src="j.png"></center>
				<center><div class="card-title">Jumana Alkhamis </div>
				<div id="detail">
					<p>“ Education promotes social progress and equality by providing opportunities for all individuals, regardless of their background, to acquire knowledge, develop skills, and participate fully in society. “</p>
					<div class="duty"></div>
				</div>
				</center>
			</div>
			<div class="card">
				<center><img src="r.png"></center>
				<center><div class="card-title">Reem Alotaibi </div>
				<div id="detail">
					<p>“ Investing in education is investing in the future, as educated individuals contribute to the advancement of their communities, drive innovation, and create a better world for generations to come. “</p>
					<div class="duty"></div>
				</div>
				</center>
			</div>
		</div>
	</div>
</body>
</html>

