<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" type="png" href="logo.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Comaptible" content="IE=edge">
    <title><?php echo "Skillbuilder"; ?></title>
    <meta name="desciption" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
</head>
<body>
    <header id="header">
        <?php include 'header.php'; ?>
        <div class="head">
            <div class="info">
                <?php 
                	echo "<p>Click get started and join our community of learning to take your skills to the next level!</p>"; 
                	echo "<h5>Education is a transformative journey that nurtures the growth of knowledge, skills, values, beliefs, and habits, sparking a profound evolution of the mind and spirit</h5>"; 
                ?>
            </div>
            <div class="start-image">
                <img src="start1.png" alt="svg">
            </div>
        </div>
    </header>
</body>
</html>




