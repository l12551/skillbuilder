<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" type="png" href="logo.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo "Skillbuilder"; ?></title>
    <meta name="desciption" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="skillbuilder-style.css">
    <script type="text/javascript" src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    <script>
        $(window).on('scroll', function(){
            if($(window).scrollTop()){
              $('nav').addClass('black');
             }else {
           $('nav').removeClass('black');
         }
        })
    </script>
</head>
<body>
 		<?php include 'header.php'; ?>
        	<div class="title">
		<center><p style="font-size: 50px; color: #073052; padding: 100px">Skills that skillbuilder will grant you!</p></center>
	       </div>
	<br><br>
<div class="course">
    <div class="cbox">
        <div class="det">
            <h5>Soft Skills</h5>
        </div>
        <div class="det">
            <h5>Creative and Design Skills</h5>
        </div>
        <div class="det">
            <h5>Business and Leadership Skills</h5>
        </div>
    </div>
</div>
        <div class="section">
		<center><p style="font-size: 50px; margin-right:100px; color: #073052; padding: 100px">More About Us</p></center>
		<div class="about-content">
			<div class="side-image">
				<img class="sideImage" src="side.png">
			</div>
			<div class="side-text">
				<h2>What do you think about how can you learn with us?</h2>
				 <p>Through the Skillbuilder Education platform, learning with qualified instructors is made incredibly simple and straightforward. Particularly in the modern day, our websites assist in making the learning process engaging and appealing for the learner. With the help of JavaScript, HTML (HyperText Markup Language), CSS (Cascading Style Sheet), PHP (Hypertext Preprocessor), and others, we can make learning more engaging and straightforward.</p>
			</div>
		</div>
     </header>
</body>
</html>
	
