<?php
$error_email = '';
$error_phone = '';
$message = '';

if (isset($_POST['submit'])) {
    $name = htmlspecialchars($_POST['name']);
    $phone = htmlspecialchars($_POST['phone']);
    $email = htmlspecialchars($_POST['email']);
    $messageText = htmlspecialchars($_POST['message']);

    // Perform input validation
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if (preg_match("/^[0-9]{10}$/", $phone)) {
            // Insert data into the database using prepared statement
            $host = "127.0.0.1";
            $user = "root";
            $pass = "root";
            $dbname = "connect";
            $conn = new mysqli($host, $user, $pass, $dbname, 3306);
            
	 // using prepare statments
            $stmt = $conn->prepare("INSERT INTO students (Name, Phone, Email, Message) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $phone, $email, $messageText);
            if ($stmt->execute()) {
                $message = "Form submitted successfully!";
            } else {
                $message = "Something went wrong. Please try again!";
            }
            $stmt->close();
            $conn->close();
        } else {
            $error_phone = "Phone number must be 10 digits and contain only numbers.";
        }
    } else {
        $error_email = "Invalid email address.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact</title>
    <style>
        body {
            margin-top:350px;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #FFF8FA;
        }

        h1 {
            text-align: center;
            color: #073052;
        }

        form {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background: #f4f4f4;
            border-radius: 5px;
        }

        form input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #073052;
            color: white;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background-color:  #073052;
        }

        .error {
            color: red;
        }

        .success-box {
            background-color: #c9fdd7;
            padding: 10px;
            border-radius: 4px;
            margin-top: 10px;
        }

        .success-message {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .success-button {
            background-color: #073052;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
<head>
<body>
	<?php include 'header.php'?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
    <h1>Contact Skillbuilder team to solve your problem!</h1>
    <?php if (!empty($message)) : ?>
        <?php if ($message === "Form submitted successfully!") : ?>
            <div class="success-box">
                <p class="success-message"><?php echo $message; ?></p>
                <a href="index.php" class="success-button">OK</a>
            </div>
        <?php else : ?>
            <p class="error"><?php echo $message; ?></p>
        <?php endif; ?>
    <?php endif; ?>
    <form action="#" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" placeholder="Please enter your name" required="required" data-error="Name is required.">

        <label for="phone">Phone:</label>
        <input type="text" name="phone" id="phone" placeholder="Please enter your phone" required="required" data-error="Phone is required.">
        <?php if (!empty($error_phone)) : ?>
            <p class="error"><?php echo $error_phone; ?></p>
        <?php endif; ?>

        <label for="email">Email:</label>
        <input type="text" name="email" id="email" placeholder="Please enter your email" required="required" data-error="Email is required.">
        <?php if (!empty($error_email)) : ?>
            <p class="error"><?php echo $error_email; ?></p>
        <?php endif; ?>

        <label for="message">Message:</label>
        <input type="text" name="message" id="message" placeholder="Please enter your message" required="required" data-error="Message is required.">

        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>

	



