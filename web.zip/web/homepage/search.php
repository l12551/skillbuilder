<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" type="png" href="logo.png">
    <meta charset="utf-8">
    <title><?php echo "Search"; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20;
            background-color: #FFF8FA;
            
        }

        .center {
            text-align: center;
            margin-top: 200px;;
        }

        table {
            width: 700px;
            height: 250px;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #CCECE6;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color:#073052
        }

        th {
            background-color: #FFF8FA;
        }

        tr:nth-child(even) {
            background-color: #FFF8FA;
        }

        .search {
            padding: 5px 15px;
            background-color: #073052;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .search:hover {
            background-color: #073052;
        }
    </style>
</head>
<body class="center">
    <?php include'header.php';?>
    <form method="POST" action="search.php">
        <input type="text" name="search" placeholder="Search here...">
        <input type="submit" class="search" name="submit" value="search"><br>
    </form>

    <?php
    $con = new PDO("mysql:host=127.0.0.1;dbname=search", "root", "root");
    if (isset($_POST['submit'])) {
        $str = $_POST['search'];
        $sth = $con->prepare("SELECT * FROM skills WHERE skill = :str");
        $sth->bindParam(':str', $str);
        $sth->setFetchMode(PDO::FETCH_OBJ);
        $sth->execute();
        if ($row = $sth->fetch()) {
            ?>
            <br><br><br>
            <table>
                <tr>
                    <th>Skills</th>
                    <th>Description</th>
                </tr>
                <tr>
                    <td><?php echo $row->skill; ?></td>
                    <td><?php echo $row->descreption; ?></td>
                </tr>
            </table>
            <?php
        } else {
            echo "No results found.";
        }
    }
    ?>
</body>
</html>
